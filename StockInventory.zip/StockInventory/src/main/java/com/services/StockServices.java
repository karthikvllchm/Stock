package com.services;

import java.util.ArrayList;
import java.util.List;

import javax.net.ssl.HttpsURLConnection;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.entity.Stock;
import com.entity.StockRepository;
import com.utils.ErrorInfo;
import com.utils.ResponseListParam;
import com.utils.ResponseParam;
import com.utils.Validator;

@Component
public class StockServices {

	@Autowired
	private Validator validate;
	
	@Autowired
	private StockRepository repository; 
	
	@Autowired
	private Environment env;
	
	public ResponseParam createStock(Stock objStock, HttpServletResponse httpResponse) {
		
		ResponseParam response = new ResponseParam();
		ErrorInfo objErrorInfo = new ErrorInfo();
		
		try {
			
			if (validate.validate(objStock, objErrorInfo)) {
				repository.save(objStock);
				objErrorInfo.setErrorCode(env.getProperty("E0000"));
				objErrorInfo.setErrorMsg(env.getProperty("E0000_MSG"));
			} 
			
		} catch (Exception ex) {
			ex.printStackTrace();
			
			httpResponse.setStatus(HttpsURLConnection.HTTP_INTERNAL_ERROR);
			objErrorInfo.setErrorCode(String.valueOf(HttpsURLConnection.HTTP_INTERNAL_ERROR));
			objErrorInfo.setErrorMsg(env.getProperty("E0000_MSMG"));
		} finally {
			response.setErrorInfo(objErrorInfo);
			response.setStock(objStock);
		}
		
		return response;
	}

	public ResponseListParam getStock(String stockNo, HttpServletResponse httpResponse) {
		
		ResponseListParam response = new ResponseListParam();
		ErrorInfo objErrorInfo = new ErrorInfo();
		
		try {
			
			if (validate.validateStockNo(stockNo, objErrorInfo)) {
				Stock stockList = repository.findById(stockNo).orElse(null);
				if (stockList == null) {
					response.setStock(null);
					objErrorInfo.setErrorCode(env.getProperty("E0006"));
					objErrorInfo.setErrorMsg(env.getProperty("E0006_MSG"));
				} else {
					List<Stock> list = new ArrayList<Stock>();
					list.add(stockList);
					
					response.setStock(list);
					objErrorInfo.setErrorCode(env.getProperty("E0000"));
					objErrorInfo.setErrorMsg(env.getProperty("E0000_MSG"));
				}
			} 
			
		} catch (Exception ex) {
			ex.printStackTrace();
			
			httpResponse.setStatus(HttpsURLConnection.HTTP_INTERNAL_ERROR);
			objErrorInfo.setErrorCode(String.valueOf(HttpsURLConnection.HTTP_INTERNAL_ERROR));
			objErrorInfo.setErrorMsg("Technical Error");
		} finally {
			response.setErrorInfo(objErrorInfo);
		}
		
		return response;
		
	}

	public ResponseListParam getAllStock(HttpServletResponse httpResponse) {
		ResponseListParam response = new ResponseListParam();
		ErrorInfo objErrorInfo = new ErrorInfo();
		
		try {
			
			List<Stock> stockList = repository.findAll();
			if (stockList == null || stockList.size() == 0) {
				response.setStock(null);
				objErrorInfo.setErrorCode(env.getProperty("E0006"));
				objErrorInfo.setErrorMsg(env.getProperty("E0006_MSG"));
			} else {
				response.setStock(stockList);
				objErrorInfo.setErrorCode(env.getProperty("E0000"));
				objErrorInfo.setErrorMsg(env.getProperty("E0000_MSG"));
			}
			
		} catch (Exception ex) {
			ex.printStackTrace();
			
			httpResponse.setStatus(HttpsURLConnection.HTTP_INTERNAL_ERROR);
			objErrorInfo.setErrorCode(String.valueOf(HttpsURLConnection.HTTP_INTERNAL_ERROR));
			objErrorInfo.setErrorMsg("Technical Error");
		} finally {
			response.setErrorInfo(objErrorInfo);
		}
		
		return response;
	}

}
