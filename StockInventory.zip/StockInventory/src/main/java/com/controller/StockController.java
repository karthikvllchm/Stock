package com.controller;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.entity.Stock;
import com.services.StockServices;
import com.utils.ResponseListParam;
import com.utils.ResponseParam;

@RestController
@RequestMapping(path = "/stock")
public class StockController {

	@Autowired
	private StockServices service;
	
	@RequestMapping(path = "/persist", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> createStock(@RequestBody Stock objStock, HttpServletResponse httpResponse) {
		ResponseParam reponse = service.createStock(objStock, httpResponse);
		return new ResponseEntity<Object>(reponse, HttpStatus.valueOf(httpResponse.getStatus()));
	}
	
		
	@GetMapping(path = "/list", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> getAllStock(HttpServletResponse httpResponse) {
		ResponseListParam reponse = service.getAllStock(httpResponse);
		return new ResponseEntity<Object>(reponse, HttpStatus.valueOf(httpResponse.getStatus()));
	}
	
	@GetMapping(path = "/list/{stockNo}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> getStock(@PathVariable String stockNo, HttpServletResponse httpResponse) {
		ResponseListParam reponse = service.getStock(stockNo, httpResponse);
		return new ResponseEntity<Object>(reponse, HttpStatus.valueOf(httpResponse.getStatus()));
	}
}
