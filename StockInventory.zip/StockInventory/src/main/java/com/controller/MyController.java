package com.controller;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import javax.net.ssl.HttpsURLConnection;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.utils.ErrorInfo;

@RestController
@RequestMapping(path = "/")
public class MyController {
	
	@Autowired
	private Environment env;
	
	private RestTemplate restTemplate = new RestTemplate();
	
	@RequestMapping(path = "/**", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> createStock(HttpServletRequest httpRequest, HttpServletResponse httpResponse) {
		
		String requestURI = httpRequest.getRequestURI();
		List<String> postRequestURI = Arrays.asList(env.getProperty("POST_REQUEST_URIS").split(","));
		ResponseEntity<Object> responseMessage;
		ErrorInfo errorInfo = new ErrorInfo();
		
		try {
			
			if(postRequestURI.contains(requestURI)) {
				String requestBody = httpRequest.getReader().lines().collect(Collectors.joining(System.lineSeparator()));
				
				if (requestBody != null && !requestBody.trim().equals("")) {
					HttpHeaders headers = new HttpHeaders();
					headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
					headers.setContentType(MediaType.APPLICATION_JSON);
					
					HttpEntity<Object> entity = new HttpEntity<Object>(requestBody, headers);
					String url = env.getProperty("app.url") + requestURI;
					responseMessage = restTemplate.exchange(url, HttpMethod.POST, entity, Object.class);

				} else {
					errorInfo.setErrorCode(env.getProperty("E0007"));
					errorInfo.setErrorMsg(env.getProperty("E0007_MSG"));
					responseMessage = new ResponseEntity<Object>(errorInfo, HttpStatus.OK);
				}
			} else {
				errorInfo.setErrorCode(env.getProperty("E0008"));
				errorInfo.setErrorMsg(env.getProperty("E0008_MSG"));
				responseMessage = new ResponseEntity<Object>(errorInfo, HttpStatus.OK);
			}
		} catch (Exception ex) {
			ex.printStackTrace();
			httpResponse.setStatus(HttpsURLConnection.HTTP_INTERNAL_ERROR);
			errorInfo.setErrorCode(String.valueOf(HttpsURLConnection.HTTP_INTERNAL_ERROR));
			errorInfo.setErrorMsg("Technical Error");
			responseMessage = new ResponseEntity<Object>(errorInfo, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
			
		return responseMessage;
	}
	
		
	@GetMapping(path = "/**", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> getStock(HttpServletRequest httpRequest, HttpServletResponse httpResponse) {
		String requestURI = httpRequest.getRequestURI();
		List<String> getRequestURI = Arrays.asList(env.getProperty("GET_REQUEST_URIS").split(","));
		ResponseEntity<Object> responseMessage;
		
		ErrorInfo errorInfo = new ErrorInfo();
		if(getRequestURI.contains(requestURI)) {
			HttpHeaders headers = new HttpHeaders();
			HttpEntity<Object> entity = new HttpEntity<Object>(headers);
			String url = env.getProperty("app.url") + requestURI;
			responseMessage = restTemplate.exchange(url, HttpMethod.GET, entity, Object.class);
		} else {
			errorInfo.setErrorCode(env.getProperty("E0008"));
			errorInfo.setErrorMsg(env.getProperty("E0008_MSG"));
			responseMessage = new ResponseEntity<Object>(errorInfo, HttpStatus.OK);
		}
			
		return responseMessage;
	}

}
