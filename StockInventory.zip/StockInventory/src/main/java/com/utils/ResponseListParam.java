package com.utils;

import java.util.List;

import com.entity.Stock;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({"errorInfo", "stock"})

public class ResponseListParam {
	private List<Stock> stock;
	private ErrorInfo errorInfo;
	
	public List<Stock> getStock() {
		return stock;
	}
	public void setStock(List<Stock> stock) {
		this.stock = stock;
	}
	public ErrorInfo getErrorInfo() {
		return errorInfo;
	}
	public void setErrorInfo(ErrorInfo errorInfo) {
		this.errorInfo = errorInfo;
	}
	
	@Override
	public String toString() {
		return "ResponseParam [stock=" + stock + ", errorInfo=" + errorInfo + "]";
	}
}
