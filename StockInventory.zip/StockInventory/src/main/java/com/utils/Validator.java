package com.utils;

import java.time.format.DateTimeFormatter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.entity.Stock;

@Component
public class Validator {
	
	@Autowired
	private Environment env;
	
	DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("YYYY/MM/DD");
	
	public boolean validate(Stock objStock, ErrorInfo objErrorInfo) {
		
		String id = objStock.getStockNo();
		if(id == null || id.trim().equals("")) {
			objErrorInfo.setErrorCode(env.getProperty("E0001"));
			objErrorInfo.setErrorMsg(env.getProperty("E0001_MSG"));
			return false;
		}
		
		String name = objStock.getStockName();
		if(name == null || name.trim().equals("")) {
			objErrorInfo.setErrorCode(env.getProperty("E0002"));
			objErrorInfo.setErrorMsg(env.getProperty("E0002_MSG"));
			return false;
		}
		
		String price = objStock.getPrice();
		try {
			Double.parseDouble(price);
		} catch (Exception ex) {
			ex.printStackTrace();
			objErrorInfo.setErrorCode(env.getProperty("E0003"));
			objErrorInfo.setErrorMsg(env.getProperty("E0003_MSG"));
			return false;
		}
		
		String purchaseDate = objStock.getPurchaseDate();
		try {
			dateFormat.parse(purchaseDate);
			//LocalDate.parse(purchaseDate, dateFormat);
		} catch (Exception ex) {
			ex.printStackTrace();
			objErrorInfo.setErrorCode(env.getProperty("E0004"));
			objErrorInfo.setErrorMsg(env.getProperty("E0004_MSG"));
			return false;
		}
		
		String quantity = objStock.getQuantity();
		try {
			Integer.parseInt(quantity);
		} catch (Exception ex) {
			ex.printStackTrace();
			objErrorInfo.setErrorCode(env.getProperty("E0005"));
			objErrorInfo.setErrorMsg(env.getProperty("E0005_MSG"));
			return false;
		}
		
		return true;
	}

	public boolean validateStockNo(String stockNo, ErrorInfo objErrorInfo) {
		if(stockNo == null || stockNo.trim().equals("")) {
			objErrorInfo.setErrorCode(env.getProperty("E0001"));
			objErrorInfo.setErrorMsg(env.getProperty("E0001_MSG"));
			return false;
		}
		return true;
	}
}
